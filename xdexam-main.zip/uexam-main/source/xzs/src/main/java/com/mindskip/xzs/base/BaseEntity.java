package com.mindskip.xzs.base;


/**
 * @author 武汉思维跳跃科技有限公司
 */
public abstract class BaseEntity {

}
